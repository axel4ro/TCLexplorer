Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class WinAPI {
    [DllImport("user32.dll")]
    public static extern bool MoveWindow(
        IntPtr hWnd, int X, int Y, int nWidth, int nHeight, bool bRepaint
    );
}
"@

# ===================== CONFIG =====================
$exePath     = "$PSScriptRoot\The Cursed Land.exe"
$processName = "The Cursed Land"
$delayMs     = 350

# compensari ANTI-GAP
$borderFixX  = 10     # border lateral
$borderFixY  = 8      # title bar
$overlapFix  = 6      # suprapunere fina (px)
# ==================================================

# ===================== UI =========================
$form = New-Object System.Windows.Forms.Form
$form.Text = "The Cursed Land | Multi-Client & Layout"
$form.Size = New-Object System.Drawing.Size(360,240)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false

$lblClients = New-Object System.Windows.Forms.Label
$lblClients.Text = "Number of clients:"
$lblClients.Location = New-Object System.Drawing.Point(20,20)
$form.Controls.Add($lblClients)

$numClients = New-Object System.Windows.Forms.NumericUpDown
$numClients.Minimum = 1
$numClients.Maximum = 12
$numClients.Value = 3
$numClients.Location = New-Object System.Drawing.Point(200,18)
$form.Controls.Add($numClients)

$btnHorizontal = New-Object System.Windows.Forms.Button
$btnHorizontal.Text = "Horizontal Layout"
$btnHorizontal.Size = New-Object System.Drawing.Size(300,40)
$btnHorizontal.Location = New-Object System.Drawing.Point(20,70)

$btnGrid = New-Object System.Windows.Forms.Button
$btnGrid.Text = "2 Rows Grid Layout"
$btnGrid.Size = New-Object System.Drawing.Size(300,40)
$btnGrid.Location = New-Object System.Drawing.Point(20,120)

$form.Controls.AddRange(@($btnHorizontal,$btnGrid))
# ==================================================

# ===================== CORE =======================
function Start-And-Arrange($clients, $layout) {

    # pornesc procesele lipsa
    while ((Get-Process -Name $processName -ErrorAction SilentlyContinue).Count -lt $clients) {
        Start-Process $exePath
        Start-Sleep -Seconds 3
    }

    # astept ferestrele
    $windows = @()
    while ($windows.Count -lt $clients) {
        $windows = Get-Process -Name $processName |
            Where-Object { $_.MainWindowHandle -ne 0 }
        Start-Sleep 1
    }

    # WORKING AREA (fara taskbar)
    $screen = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
    $W = $screen.Width
    $H = $screen.Height

    # ================= HORIZONTAL =================
    if ($layout -eq "horizontal") {

        $baseW = [int]($W / $clients + 10)
        $winW  = $baseW + $overlapFix
        $winH  = $H + $borderFixY

        for ($i = 0; $i -lt $clients; $i++) {

            $x = ($i * $baseW) - ($i * $borderFixX)
            $y = 0

            [WinAPI]::MoveWindow(
                $windows[$i].MainWindowHandle,
                $x, $y, $winW, $winH, $true
            )

            Start-Sleep -Milliseconds $delayMs
        }
    }

    # ================= GRID 2 ROWS =================
    if ($layout -eq "grid") {

        $rows = 2
        $cols = [Math]::Ceiling($clients / 2)

        $baseW = [int]($W / $cols)
        $baseH = [int]($H / $rows)

        $winW = $baseW + $overlapFix
        $winH = $baseH + $overlapFix

        for ($i = 0; $i -lt $clients; $i++) {

            $row = [Math]::Floor($i / $cols)
            $col = $i % $cols

            $x = ($col * $baseW) - ($col * $borderFixX)
            $y = ($row * $baseH) - ($row * $borderFixY)

            [WinAPI]::MoveWindow(
                $windows[$i].MainWindowHandle,
                $x, $y, $winW, $winH, $true
            )

            Start-Sleep -Milliseconds $delayMs
        }
    }
}

# ===================== EVENTS =====================
$btnHorizontal.Add_Click({
    Start-And-Arrange $numClients.Value "horizontal"
    $form.Close()
})

$btnGrid.Add_Click({
    Start-And-Arrange $numClients.Value "grid"
    $form.Close()
})

$form.ShowDialog()
