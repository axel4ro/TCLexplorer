# 📘 README – The Cursed Land | Multi-Client & Layout

## 📁 IMPORTANT – FILE LOCATION

👉  Both files must be placed in: The Cursed Land\Game

Required files:

Start_TCL_MultiClients.bat
TCL_MultiClients_Layout.ps1

⚠️ Do NOT rename these files.

The same folder must also contain: The Cursed Land.exe

## ▶️ FILE TO RUN

📄  `Start_TCL_MultiClients.bat` 

👉 This is the file you need to run.

### What it does:

* launches `The Cursed Land.exe`
* automatically opens multiple game clients
* arranges all clients based on the selected layout

You can run it:

* after login
* after teleport
* anytime the layout gets messed up

## ⚠️ REQUIRED SETTINGS

✔ Game must be  Windowed / Borderless 
❌  Fullscreen is NOT supported